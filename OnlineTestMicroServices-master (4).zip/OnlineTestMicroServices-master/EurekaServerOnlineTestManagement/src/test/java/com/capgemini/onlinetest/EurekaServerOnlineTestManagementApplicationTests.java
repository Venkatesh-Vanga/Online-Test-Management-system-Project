package com.capgemini.onlinetest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaServerOnlineTestManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
